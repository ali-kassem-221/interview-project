<?php

include_once './config/database.php';
require "../vendor/autoload.php";

use \Firebase\JWT\JWT;

if (isset($_POST['log'])) {
    $email = "";
    $password = "";


    $table = "users";
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE `Email`= '" . $email . "'";
    $result = mysqli_query($connect, $query);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);

    if ($count > 0) {

        $id = $row['user_id'];
        $firstname = $row['First Name'];
        $lastname = $row['Last Name'];
        $password2 = $row['Password'];
        $role = $row['Role'];
        if ($password == $password2) {
            if ($role == 'admin') {
                exit(header('location: ../CMS/main.php'));
            }
            $_SESSION['logged'] = "logged in successfully";
            exit(header('location:profile.php?id=' . $id . ''));
        } else {
            $_SESSION['failed'] = "password is incorrect";
            exit(header('location:login.php'));
        }
    } else $_SESSION['not_found'] = 'user not found';
} ?>
<!doctype html>
<html lang="en">

<head>
    <title>Login </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="css/style.css">

</head>

<body>
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-7 col-lg-5">
                    <div class="wrap">
                        <div class="img" style="background-image: url(images/bg-1.jpg);"></div>
                        <div class="login-wrap p-4 p-md-5">
                            <div class="d-flex">
                                <div class="w-100">
                                    <h3 class="mb-3"><?php if (isset($_SESSION['not_found'])) {
                                                            echo $_SESSION['not_found'];
                                                            unset($_SESSION['not_found']);
                                                        } ?></h3>
                                    <h3 class="mb-3"><?php if (isset($_SESSION['new'])) {
                                                            echo $_SESSION['new'];
                                                            unset($_SESSION['new']);
                                                        } ?></h3>
                                    <h3 class="mb-3"><?php if (isset($_SESSION['failed'])) {
                                                            echo $_SESSION['failed'];
                                                            unset($_SESSION['failed']);
                                                        } ?></h3>

                                    <h3 class="mb-4">Sign In</h3>
                                </div>

                            </div>
                            <form action="login.php" method="POST" class="signin-form">
                                <div class="form-group mt-3">
                                    <input type="text" name="email" class="form-control" required>
                                    <label class="form-control-placeholder" for="username">Email</label>
                                </div>
                                <div class="form-group">
                                    <input id="password-field" name="password" type=" password" class="form-control" required>
                                    <label class="form-control-placeholder" for="password">Password</label>
                                    <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                </div>
                                <div class="form-group">
                                    <button type="submit" name="log" class="form-control btn btn-primary rounded submit px-3">Sign In</button>
                                </div>
                                <div class="form-group d-md-flex">
                                    <div class="w-50 text-left">
                                        <label class="checkbox-wrap checkbox-primary mb-0">Remember Me
                                            <input type="checkbox" checked>
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    <div class="w-50 text-md-right">
                                        <a href="../index.php">Home</a>
                                    </div>
                                </div>
                            </form>
                            <p class="text-center">Not a member? <a href="create_user.php">Sign Up</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>