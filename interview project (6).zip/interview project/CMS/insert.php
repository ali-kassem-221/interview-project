<?php
include_once '../api/config/database.php';

if (isset($_POST['cancel'])) {
    exit(header('location:main.php'));
}
if (isset($_POST['create'])) {
    $firstname = '';
    $lastname = '';
    $email = '';
    $password = '';
    $role = '';
    extract($_POST);
    $rs = mysqli_query($connect, "SELECT * FROM users where Email='" . $email . "'");
    $row = mysqli_fetch_array($rs, MYSQLI_ASSOC);
    if (mysqli_num_rows($rs) > 0) {
        $rs1 = mysqli_query($connect, 'SELECT * FROM users WHERE Email="' . $email . '"');
        if (mysqli_num_rows($rs1) > 0) { //checkinng if user is already exists in the database.


            $_SESSION['err'] = 'User already  Exists!!';

            exit(header('location:insert.php'));
        }
    }
    if ($repass != $pass) {
        $_SESSION['pas'] = '<span style="font-size=5px;color:red">password didn\'t match</span>';
        exit(header('location:insert.php'));
    }

    $query2 = "INSERT INTO users (`First Name`,`Last Name`,Email,Password,Role)VALUES('" . $fname . "','" . $lname . "','" . $email . "','" . $pass . "','" . $role . "')";
    $rs1 = mysqli_query($connect, $query2) or die("Could Not Perform the Query");
    $_SESSION['new'] = "user <span style='color:lightgreen'>" . $fname . " " . " " . $lname . " </span> successfully added.";
    exit(header('location:main.php'));
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

    <div class="container">
        <div class="text-center">
            <h1><?php if (isset($_SESSION['err'])) {
                    echo $_SESSION['err'];
                    unset($_SESSION['err']);
                }
                if (isset($_SESSION['pas'])) {
                    echo $_SESSION['pas'];
                    unset($_SESSION['pas']);
                } ?></h1>
            <h1>insert new user</h1>
            <form class="form-horizontal" method="POST" action="insert.php">
                <input type="hidden" name="id">
                <div class="form-group">
                    <label class="control-label col-sm-2" for="fname">first name:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="email" placeholder="First Name" name="fname">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="lname">last name:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="pwd" placeholder="Last Name" name="lname">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="email">Email:</label>
                    <div class="col-sm-10">
                        <input type="email" class="form-control" id="email" placeholder="Enter Email" name="email">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="pass">Password:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="pwd" placeholder="Enter password" name="pass">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="repass">Password:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="pwd" placeholder="Renter  password" name="repass">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="role">Role:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="pwd" placeholder="Enter Role" name="role">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button style="width:50%" type="submit" name="create" class="btn btn-success">Apply</button><br><br>
                        <button style="width:50%" type="submit" name="cancel" class="btn btn-danger">Cancel</button>

                    </div>
                </div>
            </form>

        </div>

</body>

</html>