<?php
include_once './config/database.php';

if (isset($_POST['home'])) {
    exit(header('location:index.php'));
}
if (isset($_POST['create'])) {
    $firstname = '';
    $lastname = '';
    $email = '';
    $password = '';
    $role = '';


    // json_decode(file_get_contents("php://input"));
    // $firstName = $data->first_name;
    // $lastName = $data->last_name;
    // $email = $data->email;
    // $password = $data->password;
    // $role = $data->role;

    extract($_POST);
    $rs = mysqli_query($connect, "SELECT * FROM users where Email='" . $email . "'");
    $row = mysqli_fetch_array($rs, MYSQLI_ASSOC);
    if (mysqli_num_rows($rs) > 0) {
        $rs1 = mysqli_query($connect, 'SELECT * FROM users WHERE Email="' . $email . '"');
        if (mysqli_num_rows($rs1) > 0) { //checkinng if user is already exists in the database.


            $_SESSION['err'] = 'User already  Exists!!';

            exit(header('location:create_user.php'));
        }
    }
    if ($repass != $pass) {
        $_SESSION['pas'] = '<span style="font-size=5px;color:red">password didn\'t match</span>';
        exit(header('location:create_user.php'));
    }

    $query2 = "INSERT INTO users (`First Name`,`Last Name`,Email,Password,Role)VALUES('" . $firstname . "','" . $lastname . "','" . $email . "','" . $pass . "','" . $role . "')";
    $rs1 = mysqli_query($connect, $query2) or die("Could Not Perform the Query");
    $_SESSION['new'] = "welcome " . $firstname . " " . " " . $lastname . ".";
    exit(header('location:login.php'));
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">

    <title>Sign up</title>
</head>

<body>
    <div class="container">
        <form action="create_user.php" method="POST">
            <h1 style="text-align: center;">Sign up</h1>
            <h2><?php if (isset($_SESSION['err'])) {
                    echo $_SESSION['err'];
                    unset($_SESSION['err']);
                } else if (isset($_SESSION['pas'])) {
                    echo $_SESSION['pas'];
                    unset($_SESSION['pas']);
                } ?></h2>
            <div class="form-group mt-3">
                <input type="text" name="firstname" class="form-control" required>
                <label class="form-control-placeholder" for="username">First Name</label>
            </div>
            <div class="form-group mt-3">
                <input type="text" name="lastname" class="form-control" required>
                <label class="form-control-placeholder" for="username">Last Name</label>
            </div>
            <div class="form-group mt-3">
                <input type="text" name="email" class="form-control" required>
                <label class="form-control-placeholder" for="username">Email</label>
            </div>
            <div class="form-group">
                <input id="password-field" name="pass" type=" password" class="form-control" required>
                <label class="form-control-placeholder" for="password">Password</label>
                <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
            </div>
            <div class="form-group">
                <input id="password-field" name="repass" type=" password" class="form-control" required>
                <label class="form-control-placeholder" for="password">Password</label>
                <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
            </div>
            <div class="form-group mt-3">
                <input type="text" name="role" class="form-control" required>
                <label class="form-control-placeholder" for="username">Role</label>
            </div>
            <div class="form-group">
                <button type="submit" name="create" class="form-control btn btn-primary rounded submit px-3">Sign Up</button>
                <br><br>
                <div class="text-center"><a href="../index.php" class="btn btn-warning">Back to Home Page</a></div>

            </div>
        </form>
    </div>
</body>

</html>