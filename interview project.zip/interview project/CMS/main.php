<?php require('../api/config/database.php');
if (isset($_GET['id'])) {
    $sql = "SELECT * FROM users WHERE user_id = " . $_GET['id'] . "";
    $res = mysqli_query($connect, $sql);
    $row = mysqli_fetch_assoc($res);
    if (mysqli_num_rows($res) > 0) {
        $sql = "DELETE FROM users WHERE user_id = " . $_GET['id'] . "";
        $res = mysqli_query($connect, $sql);
        $_SESSION['deleted'] = "<span style='color:lightgreen;'>" . $row['First Name'] . "  " . $row['Last Name'] . "</span> successfully delelted";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>main</title>
</head>

<body>
    <div class="text-center">
        <h1><?php if (isset($_SESSION['deleted'])) {
                echo $_SESSION['deleted'];
                unset($_SESSION['deleted']);
            }
            if (isset($_SESSION['done_edit'])) {
                echo $_SESSION['done_edit'];
                unset($_SESSION['done_edit']);
            }
            if (isset($_SESSION['new'])) {
                echo $_SESSION['new'];
                unset($_SESSION['new']);
            }
            ?></h1>
    </div>
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <td colspan="7" align="center">
                    <h1>Users</h1>
                </td>
            </tr>
            <tr>
                <th scope="col">id</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>

            </tr>
        </thead>
        <?php

        $sql = "SELECT * FROM users";
        $res = mysqli_query($connect, $sql);
        if (mysqli_num_rows($res) > 0) :
            while ($row = mysqli_fetch_assoc($res)) :
        ?>
                <tbody>
                    <tr>
                        <th scope="row"><?= $row['user_id']; ?></th>
                        <td><?= $row['First Name']; ?></td>
                        <td><?= $row['Last Name']; ?></td>
                        <td><?= $row['Email']; ?></td>
                        <td><?= $row['Role']; ?></td>
                        <td><a class="btn btn-warning" href="edit.php?id=<?= $row['user_id']; ?>">Edit</a></td>
                        <td><a class="btn btn-danger" href="main.php?id=<?= $row['user_id']; ?>">Delete</a></td>

                    </tr>
                </tbody>
        <?php endwhile;
        endif; ?>

    </table>
    <div class="text-center"><a href="insert.php" style="width: 500px;" class="btn btn-primary">Insert New User</a></div>

</body>

</html>