<?php


require("../api/config/database.php");


if (isset($_POST['edit'])) {
    extract($_POST);
    $sql = "UPDATE users SET `First Name`='" . $fname . "',`Last Name`='" . $lname . "',`Email`='" . $email . "',`Password`='" . $pass . "',`Role`='" . $role . "' Where `user_id`='" . $id . "'";
    $result = mysqli_query($connect, $sql) or die("failed");
    $sql = "SELECT * FROM users WHERE user_id = " . $id . "";
    $result = mysqli_query($connect, $sql);
    $row = mysqli_fetch_assoc($result);
    $_SESSION['done_edit'] = "user <span style='color:lightgreen'>" . $row['First Name'] . "  " . $row['Last Name'] . "</span> successfully updated";
    exit(header('location:main.php'));
}
if (isset($_POST['cancel'])) {
    exit(header('location:main.php'));
}







?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

    <div class="container">
        <div class="text-center">
            <h1><?php if (isset($_SESSION['logged'])) {
                    echo $_SESSION['logged'];
                    unset($_SESSION['logged']);
                } ?></h1>
            <h1>Edit your profile</h1>
            <?php
            $id = $_GET['id'];
            $sql = "SELECT * FROM users WHERE `user_id` = " . $_GET['id'] . "";
            $result = mysqli_query($connect, $sql);
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);


            ?>
                <form class="form-horizontal" method="POST" action="edit.php">
                    <input type="hidden" name="id" value="<?= $row['user_id'] ?>">
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="fname">first name:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="email" value="<?= $row['First Name'] ?>" placeholder="First Name" name="fname">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="lname">last name:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="pwd" value="<?= $row['Last Name'] ?>" placeholder="Last Name" name="lname">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="email">Email:</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" id="email" value="<?= $row['Email'] ?>" placeholder="Enter Email" name="email">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="pass">Password:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="pwd" value="<?= $row['Password'] ?>" placeholder="Enter password" name="pass">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="role">Role:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="pwd" value="<?= $row['Role'] ?>" placeholder="Enter Role" name="role">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button style="width:50%" type="submit" name="edit" class="btn btn-success">Apply</button><br><br>
                            <button style="width:50%" type="submit" name="cancel" class="btn btn-danger">Cancel</button>

                        </div>
                    </div>
                </form>
            <?php
            } ?>
        </div>

</body>

</html>